//required variables
var jsforce=require('jsforce');
var fs=require('fs');
var _ = require('underscore');
var Q = require('q');
var winston = require('winston');
var mkdirp = require('mkdirp');
var json2csv = require('json2csv');
var ncp = require('ncp');


//global variables
var sourceconn,targetconn,userid,parameters,lists,recordtypemap;
var recentdaycollection = [];
var startTime = new Date();

//starting

readParameters()
.then(connectToSource)
.then(backUpApps)
.then(connectToTarget)
.then(updateRecordTypeMaps)
.then(copyFiles)
.then(readMap)
.then(updateFilesWithMap)
.then(restoreApps)
.fail(function(err){
	winston.log('error', err);
})

fs.writeFile('recentFiles.json','',function(err){});


function readParameters()
{
	winston.log('info', 'Begin reading paramters');
	var deferred = Q.defer();
	fs.readFile('parameters.json','utf8',function(err,res){
		if(err) {
			deferred.reject(err);            
		}
		else{
			winston.log('info', 'Finished reading paramters');
			parameters= JSON.parse(res);
			deferred.resolve();
		}
	})
	return deferred.promise;
}

function connectToSource()
{
	var deferred = Q.defer();    
	winston.log('info', 'attempting to connect to salesforce');
	if(parameters.source.useoauth){
		winston.log('info', 'using oauth');
		sourceconn=new jsforce.Connection({
			oauth2 : parameters.source.oauth
		});          
	}
	else{
		winston.log('info', 'without oauth');
		sourceconn=new jsforce.Connection({
			loginUrl : parameters.source.loginUrl
		});
	} 
	   
	sourceconn.bulk.pollTimeout = 60000;
	sourceconn.login(parameters.source.username,parameters.source.password)
	.then(function(userinfo){
		userid = userinfo.id;
		mkdirp(__dirname+'/source/csvs/',function(err){if(err)deferred.reject(err)});
		deferred.resolve(userinfo);
	})
	.fail(function(err){
		deferred.reject(err);
	})       

	return deferred.promise;
}

function backUpApps(){
    //var deferred = Q.defer();       
    return queryApp()
    .then(queryView)
    .then(queryShare)    
    .then(queryGroup)
    .then(queryGroupJunction)
    .then(queryStep)
    .then(queryField)
    .then(queryFieldValue)
    //return deferred.promise;
}


function queryApp(){
	winston.log('info','Querying the App');
	var deferred = Q.defer(); 
	var appFields = ['Name','Description__c','ObjectLabel__c','ObjectPluralLabel__c','ObjectShortcut__c','Status__c','wikilink__c','TECH_MigrationUniqueID__c'];
	sourceconn.sobject("App__c")
	.select(appFields.join(','))
	.where("Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{  			
			var result = json2csv({ data: records, fields: appFields });
			fs.writeFile(__dirname+'/source/csvs/app.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});
			deferred.resolve();
		}
	});
	return deferred.promise;  	
}


function queryView(){
	winston.log('info','Querying the View');
	var deferred = Q.defer(); 
	var viewfields = ['listviewdefinition__c','TECH_MigrationUniqueID__c','Name'];
	sourceconn.sobject("View__c")
	.select(viewfields.join(','))
	.where("App__r.Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{  			
			var result = json2csv({ data: records, fields: viewfields });
			fs.writeFile(__dirname+'/source/csvs/view.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});
			deferred.resolve();
		}
	});
	return deferred.promise;  	
}

function queryShare(){
	winston.log('info','Query Sharing');
	var deferred = Q.defer(); 
	var sharefields = ['AccessLevel','Parent.TECH_MigrationUniqueID__c','RowCause','UserOrGroupId'];
	sourceconn.sobject("App__Share")
	.select(sharefields.join(','))
	.where("Parent.Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{ 
			cleanrecords = records.map(function(record){
				delete record.attributes;
				delete record.Parent.attributes;
				return record;
			})
			fs.writeFile(__dirname+'/source/csvs/appshare.json',JSON.stringify(cleanrecords,null,2),function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});
			deferred.resolve();
		}
	});
	return deferred.promise;  
}


function queryGroup(){
	winston.log('info','Querying the Group');
	var deferred = Q.defer(); 
	var groupfields = ['Name','App__r.TECH_MigrationUniqueID__c','TECH_MigrationUniqueID__c'];
	sourceconn.sobject("ofwgroup__c")
	.select(groupfields)
	.where("App__r.Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{  			
			var result = json2csv({ data: records, fields: groupfields });
			fs.writeFile(__dirname+'/source/csvs/group.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});
			deferred.resolve(_.pluck(records,'TECH_MigrationUniqueID__c'));
		}
	});
	return deferred.promise;  	
}

function queryGroupJunction(groupids){
	winston.log('info','Querying the Group Junction');
	var deferred = Q.defer(); 
	try{
		var groupjunctionfields = ['Group__r.TECH_MigrationUniqueID__c','User__c','TECH_MigrationUniqueID__c'];
		var migrationids = (_.map(groupids,function(item){return "'"+item+"'"})).join(',');
	// console.log(migrationids);
	sourceconn.sobject("groupappuserjunction__c")
	.select(groupjunctionfields)
	.where("Group__r.TECH_MigrationUniqueID__c in ("+"'" + groupids.join("','") + "'"+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{  			
			var result = json2csv({ data: records, fields: groupjunctionfields });
			fs.writeFile(__dirname+'/source/csvs/groupjunction.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});
			deferred.resolve(records);
		}
	});
}
catch(ex){
	deferred.reject(ex);
}
return deferred.promise;  	
}


function queryStep(){
	winston.log('info','Querying the Step');
	var deferred = Q.defer(); 
	var stepFields = ['Name','RecordTypeId','app__r.TECH_MigrationUniqueID__c','actionvalueforapprove__c','actionvalueforreject__c','approvebuttonlabel__c','entrycondition__c','ownerselectionforthisstep__c','predefinedgroup__r.TECH_MigrationUniqueID__c','predefineduser__c','rejectbuttonlabel__c','statusvalueonentrytothisstep__c','statusvalueonrejectonthisstep__c','stepnumber__c','TECH_MigrationUniqueID__c','sendtoprevioussteplabel__c'];
	sourceconn.sobject("Step__c")
	.select(stepFields)
	.where("App__r.Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{  			
			var result = json2csv({ data: records, fields: stepFields });
			fs.writeFile(__dirname+'/source/csvs/step.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});
			deferred.resolve(records);
		}
	});
	return deferred.promise;  	
}

function queryField(){
	winston.log('info','Querying the field');
	var deferred = Q.defer(); 
	var fieldFields = ['RecordTypeId','app__r.TECH_MigrationUniqueID__c','appdatafieldmap__c','controllingfield__c','displayname__c','fields__c','fieldtype__c','helptext__c','isreadonly__c','layoutposition__c','referencelookupfield__r.TECH_MigrationUniqueID__c','required__c','section__c','step__r.TECH_MigrationUniqueID__c','targetobject__c','updatablethroughactiononly__c','updateparentonchange__c','TECH_MigrationUniqueID__c'];
	sourceconn.sobject("Field__c")
	.select(fieldFields)
	.where("App__r.Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{   			
			var result = json2csv({ data: records, fields: fieldFields });
			fs.writeFile(__dirname+'/source/csvs/field.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});

			deferred.resolve();
		}
	});
	return deferred.promise;  	
}

function queryFieldValue(){
	winston.log('info','Querying the field value');
	var deferred = Q.defer(); 
	var fieldvalueFields = ['Name','field__r.TECH_MigrationUniqueID__c','isdefault__c','TECH_MigrationUniqueID__c'];
	sourceconn.sobject("FieldValue__c")
	.select(fieldvalueFields)
	.where("Field__r.App__r.Name in ("+parameters.source.appnames.join(',')+')')
	.execute(function(err,records){
		if(err) deferred.reject(err);
		else{   					
			var result = json2csv({ data: records, fields: fieldvalueFields });
			fs.writeFile(__dirname+'/source/csvs/fieldvalue.csv',result,function(err){
				if(err) deferred.reject(err);
				else deferred.resolve()
			});  		
			deferred.resolve(finalmap);
		}
	});
	return deferred.promise;  	
}


function connectToTarget(){

	var deferred = Q.defer();    
	winston.log('info', 'attempting to connect to salesforce target');
	if(parameters.target.useoauth){
		winston.log('info', 'using oauth');
		targetconn=new jsforce.Connection({
			oauth2 : parameters.target.oauth
		});          
	}
	else{
		winston.log('info', 'without oauth');
		targetconn=new jsforce.Connection({
			loginUrl : parameters.target.loginUrl
		});
	}    
	targetconn.bulk.pollTimeout = 60000;
	targetconn.login(parameters.target.username,parameters.target.password)
	.then(function(userinfo){
		userid = userinfo.id;
		mkdirp('./target/csvs/',function(err){if(err)deferred.reject(err)});
		deferred.resolve(userinfo);
	})
	.fail(function(err){
		deferred.reject(err);
	})       

	return deferred.promise;
}

function updateRecordTypeMaps(){
	var deferred = Q.defer();
	winston.log('info','Mapping record types as having unique names is not an option');
	var recordtypequery = "Select Id,Name,DeveloperName from RecordType where SobjectType in ('App__c','Step__c','Field__c','FieldValue__c','Group__c','groupappuserjunction__c')";
	sourceconn.query(recordtypequery)
	.then(function(sourcerecords){
		var targetquery = targetconn.query(recordtypequery)
		.then(function(targetrecords){			
			var sourcerecords = targetquery.sourcerecords.records;
			var targetrecords = targetrecords.records;			
			recordtypemap={};
			_.each(sourcerecords,function(eachrecord){
				recordtypemap[eachrecord.Id] = _.findWhere(targetrecords,{'DeveloperName':eachrecord.DeveloperName}).Id;
			});					
			fs.writeFile('recordtypemap.json',JSON.stringify(recordtypemap,null,2),function(err){});	
			console.log(recordtypemap);
			deferred.resolve();
		})
		targetquery.sourcerecords = sourcerecords;
	})	
	return deferred.promise;
}

function copyFiles(){
	var deferred = Q.defer();
	
	ncp(__dirname+'/source/csvs', './target/toloadcsvs', function (err) {
		if (err) deferred.reject(err);		
		else deferred.resolve();		
	});
	return deferred.promise;
}

function readMap(){
	var deferred = Q.defer();
	fs.readFile('recordtypemap.json',function(err,data){		
		recordtypemap = JSON.parse(data);
		console.log(recordtypemap);
		deferred.resolve(recordtypemap);
	});
	return deferred.promise;
}

function updateFilesWithMap(recordtypemap){
	var deferred = Q.defer();
	console.log(__filename,__dirname);
	fs.readdir(__dirname+'/target/toloadcsvs',function(err,data){
		_.each(data,function(eachfile){
			var filelocation  = __dirname+'/target/toloadcsvs/'+eachfile;			
			var allfile = fs.readFileSync(filelocation).toString();			
			_.each(recordtypemap,function(value,key){	
				var re = new RegExp(key,"g");					
				allfile = allfile.replace(re, value);				
			});
			fs.writeFileSync(filelocation,allfile);
		})
		deferred.resolve();
	});
	return deferred.promise;
}

function restoreApps(){
	return loadApps()
	.then(loadGroups)
	.then(loadGroupAppJunction)
	.then(loadSteps)
	.then(loadFields)
	.then(loadFieldValues)
	.then(loadViews)
	.then(loadShare)	
}

function loadApps(){
	var deferred = Q.defer();
	winston.log('info','loading apps');
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/app.csv");	
	targetconn.bulk.load("app__c", "upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
			} else {				
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}
		}
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadGroups(){	
	var deferred = Q.defer();
	winston.log('info','loading groups');
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/group.csv");	
	targetconn.bulk.load("ofwgroup__c","upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);				
			} else {
				deferred.reject(rets[i].errors);
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}			
		}		
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadGroupAppJunction(){
	var deferred = Q.defer();
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/groupjunction.csv");	
	targetconn.bulk.load("groupappuserjunction__c","upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
			} else {
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}
		}
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadSteps(){
	var deferred = Q.defer();
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/step.csv");	
	targetconn.bulk.load("step__c","upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
			} else {
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}
		}
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadFields(){
	var deferred = Q.defer();
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/field.csv");	
	targetconn.bulk.load("Field__c","upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
			} else {
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}
		}
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadFieldValues(){
	var deferred = Q.defer();
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/fieldvalue.csv");	
	targetconn.bulk.load("FieldValue__c","upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
			} else {
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}
		}
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadViews(){
	var deferred = Q.defer();
	var csvFileIn = require('fs').createReadStream(__dirname+"/target/toloadcsvs/view.csv");	
	targetconn.bulk.load("View__c","upsert",{'extIdField':'TECH_MigrationUniqueID__c'}, csvFileIn, function(err, rets) {
		if (err) { return console.error(err); }
		for (var i=0; i < rets.length; i++) {
			if (rets[i].success) {
				console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
			} else {
				console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
			}
		}
		var errors = _.flatten(_.pluck(rets,'errors'));
		if(errors.length>0)
			deferred.reject(errors);
		else
			deferred.resolve();
	});
	return deferred.promise;
}

function loadShare(){
	var deferred = Q.defer();
	var jsonshare = require('fs').readFile(__dirname+"/target/toloadcsvs/appshare.json",'utf8',function(err,data){
		if(err) console.error(err);
		else{
			jsondata = JSON.parse(data);
			targetconn.sobject('App__Share').create(jsondata,function(err,res){				
				for (var i=0; i < rets.length; i++) {
					if (rets[i].success) {
						console.log("#" + (i+1) + " loaded successfully, id = " + rets[i].id);
					} else {
						console.log("#" + (i+1) + " error occurred, message = " + rets[i].errors.join(', '));
					}
				}

				var errors = _.flatten(_.pluck(rets,'errors'));
				if(errors.length>0)
					deferred.reject(errors);
				else
					deferred.resolve();
			});
		}
	});

	return deferred.promise;
}



function timetaken(){
	winston.log('info','it took '+Math.ceil(Math.abs(new Date().getTime() - startTime.getTime()) / (1000)) + 'seconds');
}

function getDiff(datestr)
{
	var currentDate=new Date();
	var recordDate=new Date(datestr);
	var timeDiff = Math.abs(currentDate.getTime() - recordDate.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
	return diffDays;
}
